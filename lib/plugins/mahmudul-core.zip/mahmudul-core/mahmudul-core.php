<?php
/**
 * Plugin Name:       Mahmudul Core
 * Plugin URI:        https://mahmudulhassan.me
 * Description:       Mahmudul theme's core functionality.
 * Version:           1.0
 * Requires at least: 5.2
 * Requires PHP:      7.2
 * Author:            Mahmudul Hassan
 * Author URI:        https://mahmudulhassan.me/
 * License:           GPL v2 or later
 * License URI:       https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain:       mahmudul-core
 * Domain Path:       /languages
 */

if ( !class_exists( 'MahmudulCore' ) ) {
    class MahmudulCore
    {
        public function __construct() {
            add_action( 'plugins_loaded', array( $this, 'mahmudu_load_textdomain' ) );
            add_action( 'init', array( $this, 'cptui_register_my_cpts' ) );
            add_action( 'init', array( $this, 'cptui_register_my_taxes' ) );
        }

        public function mahmudu_load_textdomain() {
            load_plugin_textdomain( 'mahmudul-core', null, dirname( __FILE__ ) . "/languages" );
        }

        function cptui_register_my_cpts() {

            /**
             * Post Type: Skills.
             */

            $labels = [
                "name" => __( "Skills", "mahmudul" ),
                "singular_name" => __( "Skill", "mahmudul" ),
            ];

            $args = [
                "label" => __( "Skills", "mahmudul" ),
                "labels" => $labels,
                "description" => "",
                "public" => true,
                "publicly_queryable" => true,
                "show_ui" => true,
                "show_in_rest" => true,
                "rest_base" => "",
                "rest_controller_class" => "WP_REST_Posts_Controller",
                "has_archive" => false,
                "show_in_menu" => true,
                "show_in_nav_menus" => false,
                "delete_with_user" => false,
                "exclude_from_search" => true,
                "capability_type" => "post",
                "map_meta_cap" => true,
                "hierarchical" => false,
                "rewrite" => false,
                "query_var" => true,
                "menu_position" => 25,
                "menu_icon" => "dashicons-superhero",
                "supports" => [ "title" ],
            ];

            register_post_type( "skill", $args );

            /**
             * Post Type: Services.
             */

            $labels = [
                "name" => __( "Services", "mahmudul" ),
                "singular_name" => __( "Service", "mahmudul" ),
            ];

            $args = [
                "label" => __( "Services", "mahmudul" ),
                "labels" => $labels,
                "description" => "",
                "public" => true,
                "publicly_queryable" => true,
                "show_ui" => true,
                "show_in_rest" => true,
                "rest_base" => "",
                "rest_controller_class" => "WP_REST_Posts_Controller",
                "has_archive" => false,
                "show_in_menu" => true,
                "show_in_nav_menus" => false,
                "delete_with_user" => false,
                "exclude_from_search" => true,
                "capability_type" => "post",
                "map_meta_cap" => true,
                "hierarchical" => false,
                "rewrite" => false,
                "query_var" => true,
                "menu_position" => 26,
                "menu_icon" => "dashicons-lightbulb",
                "supports" => [ "title", "editor", "thumbnail" ],
            ];

            register_post_type( "service", $args );

            /**
             * Post Type: Portfolios.
             */

            $labels = [
                "name" => __( "Portfolios", "mahmudul" ),
                "singular_name" => __( "Portfolio", "mahmudul" ),
            ];

            $args = [
                "label" => __( "Portfolios", "mahmudul" ),
                "labels" => $labels,
                "description" => "",
                "public" => true,
                "publicly_queryable" => true,
                "show_ui" => true,
                "show_in_rest" => true,
                "rest_base" => "",
                "rest_controller_class" => "WP_REST_Posts_Controller",
                "has_archive" => false,
                "show_in_menu" => true,
                "show_in_nav_menus" => false,
                "delete_with_user" => false,
                "exclude_from_search" => true,
                "capability_type" => "post",
                "map_meta_cap" => true,
                "hierarchical" => false,
                "rewrite" => [ "slug" => "portfolio", "with_front" => false ],
                "query_var" => true,
                "menu_position" => 27,
                "menu_icon" => "dashicons-slides",
                "supports" => [ "title", "editor", "thumbnail" ],
            ];

            register_post_type( "portfolio", $args );

            /**
             * Post Type: Testimonials.
             */

            $labels = [
                "name" => __( "Testimonials", "mahmudul" ),
                "singular_name" => __( "Testimonial", "mahmudul" ),
                "featured_image" => __( "Client Image", "mahmudul" ),
                "set_featured_image" => __( "Set client image", "mahmudul" ),
                "remove_featured_image" => __( "Remove client image", "mahmudul" ),
            ];

            $args = [
                "label" => __( "Testimonials", "mahmudul" ),
                "labels" => $labels,
                "description" => "",
                "public" => true,
                "publicly_queryable" => true,
                "show_ui" => true,
                "show_in_rest" => true,
                "rest_base" => "",
                "rest_controller_class" => "WP_REST_Posts_Controller",
                "has_archive" => false,
                "show_in_menu" => true,
                "show_in_nav_menus" => false,
                "delete_with_user" => false,
                "exclude_from_search" => true,
                "capability_type" => "post",
                "map_meta_cap" => true,
                "hierarchical" => false,
                "rewrite" => [ "slug" => "testimonial", "with_front" => false ],
                "query_var" => true,
                "menu_icon" => "dashicons-awards",
                "supports" => [ "title", "editor", "thumbnail" ],
            ];

            register_post_type( "testimonial", $args );
        }

        function cptui_register_my_taxes() {

            /**
             * Taxonomy: Categories.
             */

            $labels = [
                "name"          => __( "Categories", "mahmudul" ),
                "singular_name" => __( "Category", "mahmudul" ),
            ];

            $args = [
                "label"                 => __( "Categories", "mahmudul" ),
                "labels"                => $labels,
                "public"                => true,
                "publicly_queryable"    => true,
                "hierarchical"          => false,
                "show_ui"               => true,
                "show_in_menu"          => true,
                "show_in_nav_menus"     => false,
                "query_var"             => true,
                "rewrite"               => false,
                "show_admin_column"     => false,
                "show_in_rest"          => true,
                "rest_base"             => "skill_category",
                "rest_controller_class" => "WP_REST_Terms_Controller",
                "show_in_quick_edit"    => false,
            ];
            register_taxonomy( "skill_category", [ "skill" ], $args );

            /**
             * Taxonomy: Categories.
             */

            $labels = [
                "name"          => __( "Categories", "mahmudul" ),
                "singular_name" => __( "Category", "mahmudul" ),
            ];

            $args = [
                "label"                 => __( "Categories", "mahmudul" ),
                "labels"                => $labels,
                "public"                => true,
                "publicly_queryable"    => true,
                "hierarchical"          => false,
                "show_ui"               => true,
                "show_in_menu"          => true,
                "show_in_nav_menus"     => true,
                "query_var"             => true,
                "rewrite"               => [ 'slug' => 'portfolio_category', 'with_front' => true, ],
                "show_admin_column"     => false,
                "show_in_rest"          => true,
                "rest_base"             => "portfolio_category",
                "rest_controller_class" => "WP_REST_Terms_Controller",
                "show_in_quick_edit"    => false,
            ];
            register_taxonomy( "portfolio_category", [ "portfolio" ], $args );
        }


    }

    new MahmudulCore();
}

